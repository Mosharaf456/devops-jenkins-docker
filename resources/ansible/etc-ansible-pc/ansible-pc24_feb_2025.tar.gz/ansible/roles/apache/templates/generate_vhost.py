from jinja2 import Template

# Define configuration values
context = {
    "server_name": "example.com",
    "server_alias": "www.example.com",
    "document_root": "/var/www/html",
    "error_log": "example_error.log",
    "access_log": "example_access.log",
    "php_enabled": True,
    "php_version": "7.4"
}

# Load and render the template
with open("apache2_vhost.conf.j2") as file:
    template = Template(file.read())

output_conf = template.render(context)

# Save to Apache sites-available
output_path = "/etc/ansible/sites-available/apache-example.conf"
with open(output_path, "w") as f:
    f.write(output_conf)

print(f"Apache virtual host configuration generated: {output_path}")

